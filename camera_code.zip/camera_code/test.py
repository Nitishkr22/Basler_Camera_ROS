import os

image_topics = ["/camera1_images","/camera2_images","/camera3_images"]
output_dir = "./bagimage"
folder_names = ['1', 'im2', 'folder3']

for image_topic,count in enumerate(image_topics,start=1):
    folder_path = os.path.join(output_dir, f"folder{count}") 
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
        print(f"Created folder: {folder_path}")
    else:
        print(f"Folder already exists: {folder_path}")